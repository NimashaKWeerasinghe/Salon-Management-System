﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Salon_Management_System
{
    public partial class Appointment : Form
    {
        public Appointment()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }


        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Salon Mali DB\SalonMaliDB.mdf;Integrated Security=True;Connect Timeout=30");
        

        /***********************************************************************Retrieving auto increment value on load**************************************************/

        private void Appointment_Load(object sender, EventArgs e)
        {
            int ID;

            con.Open();
            string query = "SELECT MAX(AppID) FROM Appointment";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())                  /*dr = data reader, reading data from sql*/
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    txtappID.Text = "1001";
                }
                else
                {
                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtappID.Text = ID.ToString();
                }
            }
            con.Close();
        }

        /*****************************************************************************Menu Bar******************************************************************************/

        private void appointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void customerToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Customer objCustomer = new Customer();
            objCustomer.Show();
            this.Hide();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee objEmployee = new Employee();
            objEmployee.Show();
            this.Hide();
        }

        private void servicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Services objService = new Services();
            objService.Show();
            this.Hide();
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Payment objPayment = new Payment();
            objPayment.Show();
            this.Hide();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login objLogin = new Login();
            objLogin.Show();
            this.Hide();
        }


       
                                                                
        /**********************************************************************Add button**************************************************************************************/

        private void btnOK_Click(object sender, EventArgs e)
        {
            string AppID = txtappID.Text;
            string CusID = txtCusID.Text;
            string CusTel = txtCusTel.Text;
            string ServiceID1 = txtServID1.Text;
            string ServiceID2 = txtServID2.Text;
            string ServiceID3 = txtServID3.Text;
            string ServiceID4 = txtServID4.Text;
            string ServiceID5 = txtServID5.Text;

            if (CusTel == "")
            {
                MessageBox.Show("Customer Tel cannot be empty");
            }

            else if(ServiceID1=="" && ServiceID2=="" && ServiceID3 == "" && ServiceID4 == "" && ServiceID5 == "")
            {
                MessageBox.Show("Enter at least ONE service");
            }

            else if (CusID == "")
            {
                
                string CusIDqry = "SELECT CusID FROM Customer WHERE CusTel = " + CusTel + "";
                SqlCommand selectcmd = new SqlCommand(CusIDqry, con);

                try
                {
                    con.Open();
                    selectcmd.ExecuteNonQuery();

                    SqlDataReader sdr = selectcmd.ExecuteReader();
                    sdr.Read();

                    CusID = sdr["CusID"].ToString();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                con.Close();
            }


            if (CusID != "")
            {
                string qry = "INSERT INTO Appointment VALUES ('" + AppID + "' , '" + CusID + "' , '" + CusTel + "' , '" + ServiceID1 + "' , '" + ServiceID2 + "' , '" + ServiceID3 + "' , '" + ServiceID4 + "' , '" + ServiceID5 + "' ,'" + pickDate.Value.Date + "' , '" + pickTime.Value.TimeOfDay + "')";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Appointment reserved");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(AppID) FROM Appointment";         /*Auto incrementing*/
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtappID.Text = ID.ToString();
                    }


                    txtCusID.Clear();
                    txtCusTel.Clear();
                    txtServID1.Clear();
                    txtServID2.Clear();
                    txtServID3.Clear();
                    txtServID4.Clear();
                    txtServID5.Clear();
                    con.Close();
                }
            }
        }

        /************************************************************************Clear button**************************************************************************************/

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCusID.Clear();
            txtCusTel.Clear();
            txtServID1.Clear();
            txtServID2.Clear();
            txtServID3.Clear();
            txtServID4.Clear();
            txtServID5.Clear();
        }


        /***********************************************************************Update button**************************************************************************************/

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            string AppID = txtappID.Text;
            string CusID = txtCusID.Text;
            string CusTel = txtCusTel.Text;
            string ServiceID1 = txtServID1.Text;
            string ServiceID2 = txtServID2.Text;
            string ServiceID3 = txtServID3.Text;
            string ServiceID4 = txtServID4.Text;
            string ServiceID5 = txtServID5.Text;

            if (CusID == "" || CusTel == "" || ServiceID1 == "")
            {
                MessageBox.Show("Please enter required fields");
            }

            else
            {
                string qry = "UPDATE Appointment SET CusID='" + CusID + "' , CusTel = '" + CusTel + "', Serv1='" + ServiceID1 + "' , Serv2='" + ServiceID2 + "',Serv3='" + ServiceID3 + "',Serv4='" + ServiceID4 + "',Serv5='" + ServiceID5 + "' , Date= '" + pickDate.Value.Date + "' , Time = '" + pickTime.Value.TimeOfDay + "' WHERE AppID='" + AppID + "'";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Appointment updated");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(AppID) FROM Appointment";         /*Auto incrementing*/
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtappID.Text = ID.ToString();
                    }

                    txtCusTel.Clear();
                    txtServID1.Clear();
                    txtServID2.Clear();
                    txtServID3.Clear();
                    txtServID4.Clear();
                    txtServID5.Clear();
                    con.Close();
                }
            }
        }

          /***********************************************************************Delete button***************************************************************************************/


        private void btnDelete_Click(object sender, EventArgs e)
        {
            string AppID = txtappID.Text;

            string qry = "DELETE FROM Appointment WHERE AppID='" + AppID + "'";
            SqlCommand cmd = new SqlCommand(qry, con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Appointment deleted");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error" + ex.ToString());
            }
            finally
            {
                int ID;

                string autoincquery = "SELECT MAX(AppID) FROM Appointment";         /*Auto incrementing*/
                SqlCommand command = new SqlCommand(autoincquery, con);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())                  /*dr = data reader, reading data from sql*/
                {
                    string val = dr[0].ToString();

                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtappID.Text = ID.ToString();
                }

                con.Close();
            }
        }




        /***********************************************************************refresh button*******************************************************************************************/

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string refresAppointmentqry = "SELECT * FROM Appointment";        /*refreshing the appointment data grid view*/

            SqlDataAdapter daApp = new SqlDataAdapter(refresAppointmentqry, con);
            DataSet dsApp = new DataSet();

            daApp.Fill(dsApp, "Appointment");
            dgvAppointment.DataSource = dsApp.Tables["Appointment"];


            string refresServicesqry = "SELECT * FROM Services";        /*refreshing the services data grid view*/

            SqlDataAdapter daServ = new SqlDataAdapter(refresServicesqry, con);
            DataSet dsServ = new DataSet();

            daServ.Fill(dsServ, "Services");
            dgvServices.DataSource = dsServ.Tables["Services"];
        }
    }
}