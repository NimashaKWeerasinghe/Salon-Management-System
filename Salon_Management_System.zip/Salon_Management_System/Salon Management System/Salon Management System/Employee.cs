﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Salon_Management_System
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtEmpTel_TextChanged(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Salon Mali DB\SalonMaliDB.mdf;Integrated Security=True;Connect Timeout=30");

        /********************************************************************Form load********************************************************************/

        private void Employee_Load(object sender, EventArgs e)
        {
            int ID;

            con.Open();
            string query = "SELECT MAX(EmpID) FROM Employee";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())                  /*dr = data reader, reading data from sql*/
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    txtEmpID.Text = "3001";
                }
                else
                {
                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtEmpID.Text = ID.ToString();
                }
            }
            con.Close();
        }

        /*********************************************************************Menu Bar*********************************************************************/

        private void appointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Appointment objAppointment = new Appointment();
            objAppointment.Show();
            this.Hide();
        }

        private void customerToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Customer objCustomer = new Customer();
            objCustomer.Show();
            this.Hide();
        }

        private void employeeToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void servicesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Services objService = new Services();
            objService.Show();
            this.Hide();
        }

        private void paymentToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Payment objPayment = new Payment();
            objPayment.Show();
            this.Hide();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login objLogin = new Login();
            objLogin.Show();
            this.Hide();
        }


        /*********************************************************************Add button*********************************************************************/

        private void btnOK_Click(object sender, EventArgs e)
        {
            string EmpID = txtEmpID.Text;
            string EmpName = txtEmpName.Text;
            string EmpTP = txtEmpTel.Text;
            string EmpAddress = txtEmpAddress.Text;

            if (EmpName == "" || EmpTP == "" || EmpAddress == "")
            {
                MessageBox.Show("Please enter required fields");
            }
            else
            {
                string qry = "INSERT INTO Employee VALUES ('" + EmpID + "' , '" + EmpName + "','" + EmpTP + "', '" + EmpAddress + "')";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee details added");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(EmpID) FROM Employee";
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtEmpID.Text = ID.ToString();
                    }

                    txtEmpName.Clear();
                    txtEmpTel.Clear();
                    txtEmpAddress.Clear();
                    con.Close();
                }
            }
        }

        /*********************************************************************Clear button*********************************************************************/

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmpName.Clear();
            txtEmpAddress.Clear();
            txtEmpTel.Clear();
        }


        /*********************************************************************Update button*********************************************************************/

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int EmpID = int.Parse(txtEmpID.Text);
            string EmpName = txtEmpName.Text;
            string EmpTP = txtEmpTel.Text;
            string EmpAddress = txtEmpAddress.Text;

            if (EmpName == "" || EmpTP == "" || EmpAddress == "")
            {
                MessageBox.Show("Please enter required fields");
            }
            else
            {
                string qry = "UPDATE Employee SET EmpName='" + EmpName + "',EmpTel='" + EmpTP + "',EmpAddress='" + EmpAddress + "' WHERE EmpID=" + EmpID + " ";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee details updated");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(EmpID) FROM Employee";
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtEmpID.Text = ID.ToString();
                    }

                    txtEmpName.Clear();
                    txtEmpTel.Clear();
                    txtEmpAddress.Clear();
                    con.Close();
                }
            }
        }


        /*********************************************************************Delete button*********************************************************************/

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int EmpID = int.Parse(txtEmpID.Text);

            string qry = "DELETE FROM Employee WHERE EmpID=" + EmpID + " ";
            SqlCommand cmd = new SqlCommand(qry, con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee details deleted");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error" + ex.ToString());
            }
            finally
            {
                int ID;

                string autoincquery = "SELECT MAX(EmpID) FROM Employee";
                SqlCommand command = new SqlCommand(autoincquery, con);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())                  /*dr = data reader, reading data from sql*/
                {
                    string val = dr[0].ToString();

                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtEmpID.Text = ID.ToString();
                }

                txtEmpName.Clear();
                txtEmpTel.Clear();
                txtEmpAddress.Clear();
                con.Close();
            }
        }


        /********************************************************************Refresh Button********************************************************************/

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string refreshqry = "SELECT * FROM Employee";           /*refreshing data grid view*/

            SqlDataAdapter da = new SqlDataAdapter(refreshqry, con);
            DataSet ds = new DataSet();

            da.Fill(ds, "Employee");
            dgvEmployee.DataSource = ds.Tables["Employee"];
        }
    }
}
