﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Salon_Management_System
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void lblCusID_Click(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Salon Mali DB\SalonMaliDB.mdf;Integrated Security=True;Connect Timeout=30");

        /************************************************************************Retrieving auto increment value on load************************************************************************/

        private void Customer_Load(object sender, EventArgs e)
        {
            int ID;

            con.Open();
            string query = "SELECT MAX(CusID) FROM Customer";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())                  /*dr = data reader, reading data from sql*/
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    txtCusID.Text = "2001";
                }
                else
                {
                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtCusID.Text = ID.ToString();
                }
            }
            con.Close();
        }

        /************************************************************************Menu bar************************************************************************/


        private void appointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Appointment objAppointment = new Appointment();
            objAppointment.Show();
            this.Hide();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee objEmployee = new Employee();
            objEmployee.Show();
            this.Hide();
        }

        private void servicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Services objService = new Services();
            objService.Show();
            this.Hide();
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Payment objPayment = new Payment();
            objPayment.Show();
            this.Hide();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login objLogin = new Login();
            objLogin.Show();
            this.Hide();
        }



        /************************************************************************Add button************************************************************************/

        private void btnOK_Click(object sender, EventArgs e)
        {
            string CusID = txtCusID.Text;
            string CusName = txtCusName.Text;
            string CusTP = txtCusTP.Text;
            string CusEmail = txtEmail.Text;
            string gender;
            if(radioMale.Checked==true)
            {
                gender = "M";
            }
            else if(radioFemale.Checked==true)
            {
                gender = "F";
            }
            else
            {
                gender = "Not Specified";
            }

            if (CusName == "" || CusTP == "")
            {
                MessageBox.Show("Please enter required fields");
            }
            else
            {
                string qry = "INSERT INTO Customer VALUES ('" + CusID + "' , '" + CusName + "','" + CusTP + "' , '" + gender + "' , '" + CusEmail + "')";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer details added");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(CusID) FROM Customer";
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtCusID.Text = ID.ToString();
                    }

                    txtCusName.Clear();
                    txtCusTP.Clear();
                    radioMale.Checked = false;
                    radioFemale.Checked = false;
                    txtEmail.Clear();
                    con.Close();
                }
            }
        }

        /************************************************************************Clear button************************************************************************/

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCusName.Clear();
            txtCusTP.Clear();
            radioMale.Checked = false;
            radioFemale.Checked = false;
            txtEmail.Clear();
        }

        /************************************************************************Update button************************************************************************/

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int CusID = int.Parse(txtCusID.Text);
            string CusName = txtCusName.Text;
            string CusTP = txtCusTP.Text;
            string CusEmail = txtEmail.Text;
            string gender;
            if (radioMale.Checked == true)
            {
                gender = "M";
            }
            else if (radioFemale.Checked == true)
            {
                gender = "F";
            }
            else
            {
                gender = "Not Specified";
            }

            if (CusName == "" || CusTP == "")
            {
                MessageBox.Show("Please enter required fields");
            }
            else
            {
                string qry = "UPDATE Customer SET CusName = '" + CusName + "' , CusTel = '" + CusTP + "' , Gender = '" + gender + "' , Email = '" + CusEmail + "' WHERE CusID=" + CusID + " ";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer details updated");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(CusID) FROM Customer";
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtCusID.Text = ID.ToString();
                    }

                    txtCusName.Clear();
                    txtCusTP.Clear();
                    radioMale.Checked = false;
                    radioFemale.Checked = false;
                    txtEmail.Clear();
                    con.Close();
                }
            }
        }

        /************************************************************************Delete button************************************************************************/

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int CusID = int.Parse(txtCusID.Text);

            string qry = "DELETE from Customer WHERE CusID = "+CusID+" "; 
            SqlCommand cmd = new SqlCommand(qry, con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer details deleted");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error" + ex.ToString());
            }
            finally
            {
                int ID;

                string autoincquery = "SELECT MAX(CusID) FROM Customer";
                SqlCommand command = new SqlCommand(autoincquery, con);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())                  /*dr = data reader, reading data from sql*/
                {
                    string val = dr[0].ToString();

                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtCusID.Text = ID.ToString();
                }

                con.Close();
            }
        }

        


        /************************************************************************refresh button************************************************************************/

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string refreshqry = "SELECT * FROM Customer";       /*refreshing data grid view*/

            SqlDataAdapter da = new SqlDataAdapter(refreshqry, con);
            DataSet ds = new DataSet();

            da.Fill(ds, "Customer");
            dgvCustomer.DataSource = ds.Tables["Customer"];
        }
    }
}
