﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Salon_Management_System
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Salon Mali DB\SalonMaliDB.mdf;Integrated Security=True;Connect Timeout=30");

        /****************************************************************form load****************************************************************/

        private void Services_Load(object sender, EventArgs e)
        {
            int ID;
            
            
            con.Open();
            string query = "SELECT MAX(SID) FROM Services";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())                  /*dr = data reader, reading data from sql*/
            {
                string val = dr[0].ToString();
                if (val == "")
                {               /*if there is no data at all in the table, openning the page for the very first time*/
                    txtSID.Text = "4001";
                }
                else
                {               /*when table is not empty, but when re-openning the page*/
                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtSID.Text = ID.ToString();
                }
            }
            con.Close();
        }

        /*****************************************************************Menu bar*****************************************************************/

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer objCustomer = new Customer();
            objCustomer.Show();
            this.Hide();
        }

        private void appointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Appointment objAppointment = new Appointment();
            objAppointment.Show();
            this.Hide();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee objEmployee = new Employee();
            objEmployee.Show();
            this.Hide();
        }

        private void sevicesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Payment objPayment = new Payment();
            objPayment.Show();
            this.Hide();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login objLogin = new Login();
            objLogin.Show();
            this.Hide();
        }

       

        /*****************************************************************Add button*****************************************************************/

        private void btnOK_Click(object sender, EventArgs e)
        {
            string SID = txtSID.Text;
            string SName = txtSname.Text;
            

            if (SName == "" || txtSprice.Text=="")
            {
                MessageBox.Show("Please enter required fields");
            }
            else
            {
                int SPrice = int.Parse(txtSprice.Text);

                
                string qry = "INSERT INTO Services VALUES ('" + SID + "' , '" + SName + "'," + SPrice + ")";

                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Service details added");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(SID) FROM Services";
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();             /*SqlDataReader = a way to read forward rows in a table*/
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtSID.Text = ID.ToString();
                    }

                    txtSname.Clear();
                    txtSprice.Clear();
                    con.Close();
                }
            }
        }

        /*****************************************************************Clear button*****************************************************************/

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSname.Clear();
            txtSprice.Clear();
        }

        /*****************************************************************Update button*****************************************************************/

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int SID = int.Parse(txtSID.Text);
            string SName = txtSname.Text;

            if (SName == "" || txtSprice.Text=="")
            {
                MessageBox.Show("Please enter required fields");
            }
            else
            {
                int SPrice = int.Parse(txtSprice.Text);
                
                string qry = "UPDATE Services SET Sname = '" + SName + "' , SPrice=" + SPrice + " WHERE SID = " + SID + "";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery(); /*first executes, and returns the number of rows affected*/
                    MessageBox.Show("Service details updated");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(SID) FROM Services";  /*Incrementing the ID*/
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();             /*SqlDataReader = a way to read forward rows in a table*/
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString()); /*assigning the max SID to ID*/
                        ID = ID + 1;    /*incrementing the ID by 1*/
                        txtSID.Text = ID.ToString();
                    }

                    txtSname.Clear();
                    txtSprice.Clear();
                    con.Close();
                }
            }
        }


        /*****************************************************************Delete button*****************************************************************/

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int SID = int.Parse(txtSID.Text);
            
            string qry = "DELETE FROM Services WHERE SID =" + SID + " ";
            SqlCommand cmd = new SqlCommand(qry, con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Service details deleted");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error" + ex.ToString());
            }
            finally
            {
                int ID;

                string autoincquery = "SELECT MAX(SID) FROM Services";
                SqlCommand command = new SqlCommand(autoincquery, con);
                SqlDataReader dr = command.ExecuteReader();             /*SqlDataReader = a way to read forward rows in a table*/
                if (dr.Read())                  /*dr = data reader, reading data from sql*/
                {
                    string val = dr[0].ToString();

                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtSID.Text = ID.ToString();
                }

                con.Close();
            }
        }



        /****************************************************************refresh button****************************************************************/

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string refreshqry = "SELECT * FROM Services";       /*refreshing data grid view*/

            SqlDataAdapter da = new SqlDataAdapter(refreshqry, con);
            DataSet ds = new DataSet();

            da.Fill(ds, "Services");
            dgvServices.DataSource = ds.Tables["Services"];
        }
    }
}
