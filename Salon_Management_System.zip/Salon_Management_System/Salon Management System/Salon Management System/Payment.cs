﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Salon_Management_System
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        private void dgvApp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Salon Mali DB\SalonMaliDB.mdf;Integrated Security=True;Connect Timeout=30");

        /*****************************************************************form load*****************************************************************/

        private void Payment_Load(object sender, EventArgs e)
        {
            int ID;

            con.Open();
            string query = "SELECT MAX(PID) FROM Payment";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())                  /*dr = data reader, reading data from sql*/
            {
                string val = dr[0].ToString();
                if (val == "")
                {               /*if there is no data at all in the table, openning the page for the very first time*/
                    txtPaymentID.Text = "5001";
                }
                else
                {               /*when table is not empty, but when re-openning the page*/
                    ID = Convert.ToInt32(dr[0].ToString());
                    ID = ID + 1;
                    txtPaymentID.Text = ID.ToString();
                }
            }
            con.Close();
        }

        /*****************************************************************menu strip*****************************************************************/

        private void appointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Appointment objAppointment = new Appointment();
            objAppointment.Show();
            this.Hide();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer objCustomer = new Customer();
            objCustomer.Show();
            this.Hide();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee objEmployee = new Employee();
            objEmployee.Show();
            this.Hide();
        }

        private void servicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Services objServices = new Services();
            objServices.Show();
            this.Hide();
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login objLogin = new Login();
            objLogin.Show();
            this.Hide();
        }

        /*****************************************************************displaying datagrid views for APPOINTMENT & SERVICES*****************************************************************/

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtPaymentID.Text == "" || txtAppointmentID.Text == "")
            {
                MessageBox.Show("Payment ID and Appointment ID cannot be empty");
            }
            else
            {
                int AppID = int.Parse(txtAppointmentID.Text);

                string refreshAppqry = "SELECT AppID, Serv1, Serv2, Serv3, Serv4, Serv5 FROM Appointment WHERE AppID = " + AppID + " ";       /*refreshing appointment data grid view*/
                string refreshServqry = "SELECT * FROM Services";           /*refreshing services data grid view*/

                SqlDataAdapter dapp = new SqlDataAdapter(refreshAppqry, con);
                SqlDataAdapter dserv = new SqlDataAdapter(refreshServqry, con);

                DataSet ds = new DataSet();

                dapp.Fill(ds, "Appointment");
                dserv.Fill(ds, "Services");

                dgvApp.DataSource = ds.Tables["Appointment"];
                dgvServices.DataSource = ds.Tables["Services"];
            }
        }

        /*****************************************************************Assigning values to text boxes clicked from the services table****************************************/

        private void dgvServices_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            txtsid.Text = dgvServices.CurrentRow.Cells[0].Value.ToString();
            txtsname.Text = dgvServices.CurrentRow.Cells[1].Value.ToString();
            txtsprice.Text = dgvServices.CurrentRow.Cells[2].Value.ToString();

        }

        int grandtotal = 0;

        /*****************************************************************displaying selected services in data grid*****************************************************************/

        private void btnAddtodgv_Click(object sender, EventArgs e)
        {
            if(txtAppointmentID.Text=="")
            {
                MessageBox.Show("Please enter Appointment ID first");
                txtsid.Clear();
                txtsname.Clear();
                txtsprice.Clear();
            }
            else if (txtsid.Text == "" || txtsname.Text == "" || txtsprice.Text == "")
            {
                MessageBox.Show("Please select service again");
            }
            else
            {
                int total = Convert.ToInt32(txtsprice.Text);

                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(dgvDisplay);
                newRow.Cells[0].Value = txtsid.Text;
                newRow.Cells[1].Value = txtsname.Text;
                newRow.Cells[2].Value = txtsprice.Text;
                dgvDisplay.Rows.Add(newRow);

                grandtotal += total;
                lblRs.Text = "Rs." + grandtotal;
            }
        }

        /*****************************************************************adding details to payment table*****************************************************************/

        private void btnAddPaym_Click(object sender, EventArgs e)
        {
            if (txtAppointmentID.Text == "" || grandtotal == 0)
            {
                MessageBox.Show("Please add services");
            }
            else
            {
                int AppID = int.Parse(txtAppointmentID.Text);

                string qry = "INSERT INTO Payment (PID, AppID, grandtotal) VALUES ('" + txtPaymentID.Text + "' , '" + AppID + "', '" + grandtotal + "')";
                SqlCommand cmd = new SqlCommand(qry, con);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Payment details recorded");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error" + ex.ToString());
                }
                finally
                {
                    int ID;

                    string autoincquery = "SELECT MAX(PID) FROM Payment";
                    SqlCommand command = new SqlCommand(autoincquery, con);
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())                  /*dr = data reader, reading data from sql*/
                    {
                        string val = dr[0].ToString();

                        ID = Convert.ToInt32(dr[0].ToString());
                        ID = ID + 1;
                        txtPaymentID.Text = ID.ToString();
                    }

                    txtAppointmentID.Clear();
                    txtsid.Clear();
                    txtsname.Clear();
                    txtsprice.Clear();
                    lblRs.Text = "Rs. ";
                    con.Close();
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string refreshqry = "SELECT * FROM Payment";       /*refreshing data grid view*/

            SqlDataAdapter da = new SqlDataAdapter(refreshqry, con);
            DataSet ds = new DataSet();

            da.Fill(ds, "Payment");
            dgvPayment.DataSource = ds.Tables["Payment"];
        }
    }
}